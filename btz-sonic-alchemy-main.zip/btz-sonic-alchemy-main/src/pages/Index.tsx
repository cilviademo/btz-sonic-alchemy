import { EnhancedBTZPlugin } from '@/components/vst/EnhancedBTZPlugin';

const Index = () => {
  return (
    <div className="min-h-screen bg-background p-4 flex items-center justify-center">
      <EnhancedBTZPlugin />
    </div>
  );
};

export default Index;